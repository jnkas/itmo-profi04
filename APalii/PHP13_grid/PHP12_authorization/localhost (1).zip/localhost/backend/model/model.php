<?php
# Задание 1 
class Model {

    public function getPage() {
    	//App::$DB::execute('select * from t where id = :id',['id'=>100 ] ); 
        //App::input->get('login');
        $name = $_GET['name']; 
        $pass = $_GET['pass']; 
        // экранирование одинарной ковычки 
        
        $query = "insert into auth values (100, :name, :pass)"; 

    	$result =  DatabaseHandler::execute($query, ['name'=>$name , 'pass'=>$pass ]); 

    	$result =  DatabaseHandler::GetAll('select name, pass from auth where id_auth = :id', ['id'=>1 ] ); 
        return $result;
        
    }
}