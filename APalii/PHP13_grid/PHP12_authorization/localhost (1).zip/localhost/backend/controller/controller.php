<?php

class Debug {
	public static function log ($value , $descr='') {
		echo "<pre>";
        echo $descr;
        var_dump($value);
		echo "</pre>";
	}

}

class Controller {
    public function index() {
        $mdl = new Model();
        
        $view = new View('index.tpl');
        
        $result = $mdl->getPage(); 

        Debug::log($result);
        

        exit();

        $view->render(['data'=> 10 , 'b' => 20]);
        echo $view->getHTML();              
    }
}