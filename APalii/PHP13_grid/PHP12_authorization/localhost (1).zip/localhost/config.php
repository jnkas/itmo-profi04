<?php


define ('DB_HOST' , 'localhost');
define ('DB_NAME' , 'fly');
define ('DB_USERNAME' , 'ivan');
define ('DB_PASSWORD' , '123');
define ('PDO_DSN' , 'mysql:host='.DB_HOST.';dbname='.DB_NAME);
