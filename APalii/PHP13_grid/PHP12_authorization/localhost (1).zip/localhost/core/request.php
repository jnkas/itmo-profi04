<?php

class Request {
// ваш код

}

class Input {
	// ваш код
}