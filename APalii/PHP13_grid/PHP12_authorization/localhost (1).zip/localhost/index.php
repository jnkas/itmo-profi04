<?php

define('TEMPLATE_PATH' , './asset/tpl/');

include "./core/app.php";

App::run();








